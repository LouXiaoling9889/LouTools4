
// javascript

$(function() {

	// to top
	$('#gotop').click(function() {
		$('html, body').animate({
            scrollTop: 0
        }, 500);
	})
});